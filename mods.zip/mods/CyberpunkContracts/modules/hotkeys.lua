-- ============================================================================
-- modules/hotkeys.lua
-- Functional dev/mechanic hotkeys. Bind in the CET "Bindings" tab.
-- (Inspect Attitude + Device Info were removed — the editor focus inspector
--  covers both live.)
--
-- AI hotkeys reuse the shared helpers in modules/actions / spawn. Device/door
-- hotkeys operate on whatever you're looking at, via the PS-event pattern —
-- these run the Phase 0 welded-door test.
-- ============================================================================

return function(CC)

    -- Queue a device PS event on the looked-at entity.
    local function onLookAtDevice(actionClass, name)
        local ent = CC.lookAt()
        if not ent then CC.log(name .. ": aim at a device/door"); return end
        if not actionClass then CC.log(name .. ": class is NIL (not a valid class in this build)"); return end
        local raw = "?"; pcall(function() raw = tostring(ent:GetEntityID().hash) end)
        local stored = CC.entityHash and CC.entityHash(ent) or "?"   -- exactly what bind would store
        local ok, err = pcall(function()
            local ps = ent:GetDevicePS()
            if not ps then error("no DevicePS on " .. tostring(ent:GetClassName()), 0) end
            local a = actionClass.new()
            a:SetUp(ps)
            a:SetExecutor(Game.GetPlayer())
            Game.GetPersistencySystem():QueuePSDeviceEvent(a)
        end)
        if ok then CC.log(name .. " -> " .. tostring(ent:GetClassName()) .. "  raw=" .. raw .. "  stored=" .. stored)
        else        CC.log(name .. ": FAILED - " .. tostring(err) .. "  raw=" .. raw) end
    end

    -- ---- doors -------------------------------------------------------------

    -- Unlock + open the door you're aiming at (the common "open this locked door").
    registerHotkey("CCDoorOpen", "CC: Door unlock + open", function()
        onLookAtDevice(QuestForceUnlock, "QuestForceUnlock")
        onLookAtDevice(QuestForceOpen,   "QuestForceOpen")
    end)

    -- ---- editor: add / place / move objects --------------------------------

    -- Add the world object under the crosshair into the open blueprint as a Device.
    -- Same capture path as the Place window's Device button; auto-names DeviceN.
    registerHotkey("CCBindDevice", "CC: Add device at crosshair", function()
        local ed = CC.editor
        local bp = ed and ed.blueprint
        if not bp then CC.log("add device: no mission open in the editor"); return end
        bp.entities = bp.entities or {}
        local used = {}
        for _, en in ipairs(bp.entities) do if en.label then used[en.label] = true end end
        local n, name = 1, "Device1"
        while used[name] do n = n + 1; name = "Device" .. n end
        local e, err = CC.captureDevice(name)
        if not e then CC.log("add device: " .. tostring(err)); return end
        if CC.pushUndo then CC.pushUndo() end
        bp.entities[#bp.entities + 1] = e
        ed.dirty = true
        ed.selectedLabel = name
        CC.log("added device '" .. name .. "' (" .. tostring(e.class) .. ")")
    end)

    registerHotkey("CCPlaceSquare", "CC: Place square node at V",    function() CC.placeZoneAtV("box")    end)
    registerHotkey("CCPlaceCircle", "CC: Place circle node at V",    function() CC.placeZoneAtV("sphere") end)
    registerHotkey("CCMoveSelToV",  "CC: Move selected object to V", function() CC.moveSelectedToV()      end)

    -- ---- VFX / status-FX tests (just press them and watch) -----------------
    -- Targets whatever you're aiming at, else V. Status path is the proven one
    -- (a shipping mod uses GetStatusEffectSystem():ApplyStatusEffect); the raw VFX
    -- path is the experiment. Each cycles a list so you can mash and compare.

    local function ffTarget() return CC.lookAt() or Game.GetPlayer() end

    -- Status effects (confirmed CET path) -- these play VFX *and* gameplay.
    local STATUS_FX = {
        "BaseStatusEffect.SmokeBomb",       -- smoke cloud (very visible)
        "BaseStatusEffect.Stun",            -- stun
        "BaseStatusEffect.Knockdown",       -- ragdoll
        "BaseStatusEffect.BaseEMP",         -- EMP
        "BaseStatusEffect.Bleeding",        -- blood
        "BaseStatusEffect.BerserkNPCBuff",  -- berserk aura
        "BaseStatusEffect.BaseOverheat",    -- fire / overheat
        "BaseStatusEffect.SandstormAbstract",
    }
    local sIdx = 0
    registerHotkey("CCTestStatusFX", "CC: TEST status FX (cycle)", function()
        local ent = ffTarget()
        sIdx = (sIdx % #STATUS_FX) + 1
        local rec = STATUS_FX[sIdx]
        local ok, err = pcall(function()
            Game.GetStatusEffectSystem():ApplyStatusEffect(ent:GetEntityID(), rec)
        end)
        if ok then CC.log("statusFX -> " .. rec .. "  on " .. tostring(ent:GetClassName()) .. "  (watch it)")
        else        CC.log("statusFX FAILED: " .. rec .. " -- " .. tostring(err)) end
    end)

    -- Raw VFX (experimental StartEffectEvent path) -- visual only, may not bind.
    local RAW_VFX = {
        "status_smoke_bomb", "status_burning", "status_electrocuted", "status_emp",
        "igni", "empExplosionDestruction", "mask_explode", "w_expl_blackwall_shortcircuit",
    }
    local vIdx = 0
    registerHotkey("CCTestRawVFX", "CC: TEST raw VFX (cycle)", function()
        local ent = ffTarget()
        vIdx = (vIdx % #RAW_VFX) + 1
        local name = RAW_VFX[vIdx]
        local ok, err = pcall(function()
            GameObjectEffectHelper.StartEffectEvent(ent, CName.new(name))
        end)
        if ok then CC.log("rawVFX -> " .. name .. "  (if nothing shows, this path isn't bound on your build)")
        else        CC.log("rawVFX FAILED: " .. name .. " -- " .. tostring(err)) end
    end)

    -- Strip the test status effects back off the target.
    registerHotkey("CCClearFX", "CC: Clear test FX (status + raw)", function()
        local ent = ffTarget()
        local ses = Game.GetStatusEffectSystem()
        for _, rec in ipairs(STATUS_FX) do pcall(function() ses:RemoveStatusEffect(ent:GetEntityID(), rec) end) end
        -- Raw VFX aren't status effects, so RemoveStatusEffect can't touch them --
        -- that's why the glitch stuck. They need the StartEffectEvent counterpart.
        for _, name in ipairs(RAW_VFX) do pcall(function() GameObjectEffectHelper.StopEffectEvent(ent, CName.new(name)) end) end
        CC.log("cleared test FX (status + raw)")
    end)

    -- World-space FX: plays a .effect/.particle at a TRANSFORM (not anchored to an
    -- entity) via the FxSystem -- this is the explosion/smoke-at-a-point layer the
    -- StartEffectEvent path couldn't reach. Mirrors FX Player's PlayEffectOnCoords.
    -- Falsify this before wiring play_fx / explode. Cycles a few explosion/fire paths.
    local WORLD_FX = {
        "base\\fx\\devices\\fuel_dispener\\d_fuel_dispener_explosion_001.effect",
        "base\\fx\\devices\\explosive_server\\d_explosive_server_explosion.effect",
        "base\\fx\\devices\\explosive_tank\\d_explosive_tank_gas_flames.effect",
        "base\\fx\\characters\\boss_cyberninja\\ch_cyberninja_mask_explode.effect",
        "base\\fx\\characters\\boss_animals\\animals_boss_weakspot_explode.effect",
        "base\\fx\\characters\\npc\\_common\\status_burning.effect",
        "base\\fx\\characters\\boss_animals\\hammer\\hammer_throw_ground_smoke.effect",
    }
    local wIdx = 0
    registerHotkey("CCTestWorldFX", "CC: TEST world FX at crosshair", function()
        local p = Game.GetPlayer()
        local pos, fwd = p:GetWorldPosition(), p:GetWorldForward()
        wIdx = (wIdx % #WORLD_FX) + 1
        local path = WORLD_FX[wIdx]
        local ok, err = pcall(function()
            local t = WorldTransform.new()
            t:SetOrientation(p:GetWorldOrientation())
            t:SetPosition(Vector4.new(pos.x + fwd.x * 3.0, pos.y + fwd.y * 3.0, pos.z, 1.0))
            local fx  = Game.GetFxSystem()
            local res = gameFxResource.new({ effect = path })
            local h2  = fx:SpawnEffect(res, t)
            if not IsDefined(h2) then fx:SpawnEffectOnGround(res, t, true) end
        end)
        if ok then CC.log("worldFX -> " .. path)
        else        CC.log("worldFX FAILED: " .. tostring(err)) end
    end)

    -- Prove the damage call on ONE NPC before it ever loops a radius: read Health,
    -- hit it for 25, read again. If HP drops, CC.damageEntity is good for explode.
    registerHotkey("CCTestDamage", "CC: TEST damage look-at NPC", function()
        local ent = CC.lookAt()
        if not ent then CC.log("damage: aim at an NPC"); return end
        local function hp()
            local v = -1
            pcall(function() v = Game.GetStatPoolsSystem():GetStatPoolValue(ent:GetEntityID(), gamedataStatPoolType.Health, false) end)
            return v
        end
        local before = hp()
        CC.damageEntity(ent, 25)
        local after = hp()
        CC.log(string.format("damage: HP %.1f -> %.1f on %s", before, after, tostring(ent:GetClassName())))
    end)

    -- ---- PROP SPAWN TEST (stability-critical) -------------------------------
    -- exEntitySpawner = CET's prop spawner (what AMM / World Builder use). Props are
    -- .ent template paths. I can't verify exact base-game paths from here, so SET ONE:
    -- copy a path from AMM's prop browser / World Builder, paste into PROP_PATHS.
    -- PROTOCOL: spawn ONE -> confirm it appears -> despawn -> confirm it's gone ->
    -- then SAVE + RELOAD the save and confirm it did NOT come back (no save leak).
    local PROP_PATHS = {
        -- [VERIFY] replace with real .ent paths (these are plausible guesses only):
        "base\\environment\\decoration\\furniture\\chair\\chair_office_a.ent",
        "base\\environment\\architecture\\common\\int\\containers\\container_crate_a.ent",
    }
    CC.spawnedProps = CC.spawnedProps or {}
    local pIdx = 0
    registerHotkey("CCSpawnProp", "CC: TEST spawn prop at crosshair", function()
        if not exEntitySpawner then CC.log("prop: exEntitySpawner missing (update CET)"); return end
        local p = Game.GetPlayer()
        local pos, fwd = p:GetWorldPosition(), p:GetWorldForward()
        pIdx = (pIdx % #PROP_PATHS) + 1
        local path = PROP_PATHS[pIdx]
        local id
        local ok, err = pcall(function()
            local t = WorldTransform.new()
            t:SetOrientation(p:GetWorldOrientation())
            t:SetPosition(Vector4.new(pos.x + fwd.x * 2.0, pos.y + fwd.y * 2.0, pos.z, 1.0))
            id = exEntitySpawner.Spawn(path, t, "")
        end)
        if ok and id then
            CC.spawnedProps[#CC.spawnedProps + 1] = id
            CC.log("prop: spawned '" .. path .. "'  (tracking " .. #CC.spawnedProps .. ")")
        else
            CC.log("prop: FAILED '" .. path .. "' -- " .. tostring(err) .. "  (set a real .ent path)")
        end
    end)

    registerHotkey("CCClearProps", "CC: Despawn test props", function()
        local n, gone = #(CC.spawnedProps or {}), 0
        for _, id in ipairs(CC.spawnedProps or {}) do
            local ok = false
            pcall(function() local e = Game.FindEntityByID(id); if e then e:Dispose(); ok = true end end)
            if not ok then pcall(function() Game.GetDynamicEntitySystem():DeleteEntity(id); ok = true end) end
            if ok then gone = gone + 1 end
        end
        CC.spawnedProps = {}
        CC.log("prop: despawned " .. gone .. "/" .. n .. " (look around -- any ghosts left?)")
    end)

    -- Verify freeze + hide on the look-at NPC before trusting the verbs. Each toggles.
    local froze = false
    registerHotkey("CCTestFreeze", "CC: TEST freeze toggle (look-at)", function()
        local ent = CC.lookAt()
        if not ent then CC.log("freeze: aim at an NPC"); return end
        froze = not froze
        CC.freezeEntity(ent, froze)
        CC.log("freeze: " .. (froze and "FROZEN" or "released") .. " " .. tostring(ent:GetClassName()))
    end)

    local hid = false
    registerHotkey("CCTestHide", "CC: TEST hide toggle (look-at)", function()
        local ent = CC.lookAt()
        if not ent then CC.log("hide: aim at an NPC"); return end
        hid = not hid
        local how = CC.hideEntity(ent, hid)
        CC.log("hide: " .. (hid and "HIDDEN" or "shown") .. " via " .. tostring(how) .. " on " .. tostring(ent:GetClassName()))
    end)

    -- ========================================================================
    -- FACTION-FIGHT TEST HARNESS (falsify-first, per the research doc).
    -- Spawn 2 of side A + 2 of side B, wait for puppets to ATTACH
    -- (GetAttitudeAgent ~= nil), then pairwise SetAttitudeTowards: cross-side
    -- hostile, same-side friendly -- with read-back, so we separate "did the
    -- write take" from "did they fight". Wiring is driven by TickAlways (no Cron
    -- here). These are throwaway NPCs, NOT mission entities; ffClear despawns them.
    -- ========================================================================
    local FF_RECORD_A = "Character.q001_scavenger_shotgun3"                               -- spawnable (proven)
    local FF_RECORD_B = "Character.sts_wat_nid_04_enemy_maelstrom_fast_sniper2_grad_ma"   -- VERIFY: swap if it never resolves

    local function ffSpawn(record, pos)
        local id
        pcall(function()
            local spec = DynamicEntitySpec.new()
            spec.recordID      = TweakDBID.new(record)
            spec.position      = pos
            spec.orientation   = Quaternion.new(0, 0, 0, 1)
            spec.persistState  = false
            spec.persistSpawn  = false
            spec.alwaysSpawned = true
            spec.tags          = { CName.new("CyberpunkContracts") }
            id = Game.GetDynamicEntitySystem():CreateEntity(spec)
        end)
        return id
    end

    -- Drained by TickAlways: once every spawned agent resolves (or a 6s timeout),
    -- wire the attitude cross-product ONCE and read it back.
    function CC.tickFactionTest(dt)
        local st = CC.ffTest
        if not st or st.wired then return end
        local waited = os.clock() - st.t0
        if waited < 1.0 then return end
        local A, B, ready = {}, {}, true
        for _, id in ipairs(st.a) do
            local e = Game.FindEntityByID(id); local ag = e and e:GetAttitudeAgent()
            if ag then A[#A + 1] = ag else ready = false end
        end
        for _, id in ipairs(st.b) do
            local e = Game.FindEntityByID(id); local ag = e and e:GetAttitudeAgent()
            if ag then B[#B + 1] = ag else ready = false end
        end
        if not ready and waited < 6.0 then return end
        st.wired = true
        if #A == 0 or #B == 0 then
            CC.log("[FF] ABORT: agents never resolved (A=" .. #A .. " B=" .. #B .. ") -- does FF_RECORD_B spawn?")
            return
        end
        CC.log(string.format("[FF] wiring A=%d B=%d (waited %.1fs)", #A, #B, waited))
        for _, agA in ipairs(A) do
            for _, agB in ipairs(B) do
                pcall(function()
                    local before = agA:GetAttitudeTowards(agB)
                    agA:SetAttitudeTowards(agB, EAIAttitude.AIA_Hostile)
                    agB:SetAttitudeTowards(agA, EAIAttitude.AIA_Hostile)
                    local after = agA:GetAttitudeTowards(agB)
                    CC.log("[FF] cross  before=" .. tostring(before) .. "  after=" .. tostring(after))
                end)
            end
        end
        local function bindFriendly(grp)
            for i = 1, #grp do for j = i + 1, #grp do
                pcall(function()
                    grp[i]:SetAttitudeTowards(grp[j], EAIAttitude.AIA_Friendly)
                    grp[j]:SetAttitudeTowards(grp[i], EAIAttitude.AIA_Friendly)
                end)
            end end
        end
        bindFriendly(A); bindFriendly(B)
        CC.log("[FF] wired. If cross reads AIA_Hostile but they idle -> it's sensing/placement,")
        CC.log("[FF] not the write. Put them in line-of-sight, or use FactionFight: Force engage.")
    end

    registerHotkey("ffSpawn", "FactionFight: Spawn A vs B", function()
        local p   = CC.worldPos and CC.worldPos(Game.GetPlayer())
        local fwd = nil; pcall(function() fwd = Game.GetPlayer():GetWorldForward() end)
        if not p or not fwd then CC.log("[FF] no player pos/forward"); return end
        local right = { x = fwd.y, y = -fwd.x }                    -- horizontal perpendicular
        local function ffAt(fdist, side)                           -- in front of V, offset left/right
            return Vector4.new(p.x + fwd.x * fdist + right.x * side,
                               p.y + fwd.y * fdist + right.y * side,
                               p.z, 1.0)
        end
        local a, b, all = {}, {}, {}
        for i = 1, 2 do
            local idA = ffSpawn(FF_RECORD_A, ffAt(6 + i, -3))      -- left cluster
            local idB = ffSpawn(FF_RECORD_B, ffAt(6 + i,  3))      -- right cluster, ~6m across, in LOS
            if idA then a[#a + 1] = idA; all[#all + 1] = idA end
            if idB then b[#b + 1] = idB; all[#all + 1] = idB end
        end
        CC.ffTest = { a = a, b = b, all = all, t0 = os.clock(), wired = false }
        CC.log("[FF] spawned A=" .. #a .. " B=" .. #b .. " in front of V -- wiring after attach")
    end)

    registerHotkey("ffClear", "FactionFight: Despawn test NPCs", function()
        local st = CC.ffTest
        if st then
            for _, id in ipairs(st.all) do
                pcall(function() Game.GetDynamicEntitySystem():DeleteEntity(id) end)
            end
        end
        CC.ffTest = nil
        CC.log("[FF] cleared")
    end)

    registerHotkey("ffPoke", "FactionFight: Force engage (report back)", function()
        -- Phase 2 only: use IF the cross read-back showed AIA_Hostile but they still
        -- idle. The right combat nudge (stim broadcast vs AI command vs alert state)
        -- needs a method verified on YOUR build, so this reports instead of guessing.
        if not CC.ffTest then CC.log("[FF] nothing spawned"); return end
        CC.log("[FF] if they idled after a confirmed AIA_Hostile, tell me and I'll wire a")
        CC.log("[FF] verified combat nudge. First move them into clear line-of-sight.")
    end)

end
