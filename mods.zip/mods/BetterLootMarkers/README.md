# BetterLootMarkers - Cyberpunk 2077 mod

![Screenshot](screenshot.png "BetterLootMarkers Mod")
This is a Cyberpunk 2077 mod that adds detailed loot markers on looting containers and dropped loot.

If a container contains items of different types (armor, weapon, eddies), an icon for each category will show instead of the default loot marker, with different colored icons to represent the highest quality loot in each category.

## Installation

This mod requires [Cyber Engine Tweaks](https://github.com/yamashi/CyberEngineTweaks) Version 1.34.1+ (also on [Nexus](https://www.nexusmods.com/cyberpunk2077/mods/107)) to be installed.

Extract the entire repository into `Cyberpunk 2077\bin\x64\plugins\cyber_engine_tweaks\mods\` and run the game.

[Optional] Set "Vertical Mode" to true in the Cyber Engine Tweaks overlay to change the display mode of the markers to vertical
[Optional] Set "Show Default Markers" to true in the Cyber Engine Tweaks overlay to change bring back the original markers alongside Better Loot Markers
[Optional] Use "Marker Scaling" to change the size of the markers

Tested to work on Cyberpunk version 2.31

## Packaging for Nexus Mods

Use the included executable batch script from the mod root:

`pack-for-nexus.bat 1.2.0`

This creates a Nexus-ready zip in `dist/` with the correct game folder structure:

`bin/x64/plugins/cyber_engine_tweaks/mods/BetterLootMarkers/...`

If no version is provided, it defaults to `dev`:

`pack-for-nexus.bat`

The default version comes from `version.txt` (also used by the mod at runtime and printed in CET log on startup).

## Issues and Contributions

Feel free to open an issue if you encounter a bug or suggest a pull request.

## Credits and Thanks

- psiberx from the Cyberpunk 2077 Modding Community Discord server for pointing me in the right direction and providing helpful code samples
- Various other CET mod authors whose mods I looked at while learning to make cyberpunk mods
- The amazing https://redmodding.org/ team for CET and a million other resources and documentations
