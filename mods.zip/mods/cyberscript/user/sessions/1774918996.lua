-- 1774918905
return {
	["arrayFactionScore"] = {
	},
	["arrayPlayerItems"] = {
	},
	["savedStates"] = {
	},
	["garage"] = {
	},
	["arrayHUD"] = {
	},
	["myAvatar"] = "Character.Judy",
	["arrayQuestStatut"] = {
	},
	["arrayAffinity"] = {
	},
	["Score"] = {
	},
	["arrayHousing"] = {
	},
	["arrayPlayerData"] = {
	},
	["Variable"] = {
		["faction_maelstrom"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_animals"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_valentinos"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["player"] = {
			["current_gang"] = "faction_mox",
		},
		["faction_trauma"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_ncpd"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_aldecaldos"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_delamain"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_arasaka"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_voodooboys"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["player_rotation"] = {
			["roll"] = "0.000",
			["pitch"] = "0.000",
			["yaw"] = "55.000",
		},
		["faction_kangtao"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_afterlife"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_maxtac"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_tygerclaws"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_wraiths"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_sixthstreet"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_scavengers"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["Affinity"] = {
			["faction_scavengers"] = -6,
			["faction_wraith"] = -5,
			["faction_maelstrom"] = -5,
			["Panam"] = 50,
			["Kerry"] = 10,
			["faction_ncpd"] = 5,
			["faction_aldecaldos"] = 5,
			["faction_mox"] = 5,
			["Meredith Stout"] = 50,
			["faction_voodooboys"] = -10,
		},
		["faction_mox"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["game"] = {
			["loaded_gang_affinity"] = true,
		},
		["player_position"] = {
			["y"] = "2913.909",
			["z"] = "7.175",
			["x"] = "-1256.379",
		},
		["current_district"] = {
			["tag"] = "district_watson",
			["subdistrict_enum"] = "Northside",
			["stateName"] = "Neutral",
			["districttext"] = "Watson  |  Northside (Neutral)",
			["enum"] = "Watson",
			["state"] = 1,
		},
		["faction_militech"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
	},
	["arrayHouseStatut"] = {
	},
}