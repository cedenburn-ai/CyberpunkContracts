-- 1774922057
return {
	["savedStates"] = {
	},
	["Variable"] = {
		["player"] = {
			["current_gang"] = "faction_mox",
		},
		["faction_kangtao"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_afterlife"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_maxtac"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_tygerclaws"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_wraiths"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_militech"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_scavengers"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["player_rotation"] = {
			["roll"] = "0.000",
			["pitch"] = "0.000",
			["yaw"] = "121.627",
		},
		["faction_delamain"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["Affinity"] = {
			["faction_voodooboys"] = -10,
			["Panam"] = 50,
			["faction_wraith"] = -5,
			["faction_maelstrom"] = -5,
			["faction_mox"] = 5,
			["faction_scavengers"] = -6,
			["Kerry"] = 10,
			["faction_ncpd"] = 5,
			["faction_aldecaldos"] = 5,
			["Meredith Stout"] = 50,
		},
		["current_district"] = {
			["enum"] = "Watson",
			["stateName"] = "Neutral",
			["state"] = 1,
			["subdistrict_enum"] = "Northside",
			["tag"] = "district_watson",
			["districttext"] = "Watson  |  Northside (Neutral)",
		},
		["faction_sixthstreet"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_valentinos"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_animals"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_voodooboys"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_maelstrom"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_mox"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["game"] = {
			["loaded_gang_affinity"] = true,
		},
		["faction_trauma"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_ncpd"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_aldecaldos"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["player_position"] = {
			["z"] = "7.138",
			["x"] = "-1842.884",
			["y"] = "2717.888",
		},
		["faction_arasaka"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
	},
	["garage"] = {
	},
	["arrayHUD"] = {
	},
	["myAvatar"] = "Character.Judy",
	["arrayQuestStatut"] = {
	},
	["Score"] = {
	},
	["arrayFactionScore"] = {
	},
	["arrayPlayerData"] = {
	},
	["arrayAffinity"] = {
	},
	["arrayHouseStatut"] = {
	},
	["arrayHousing"] = {
	},
	["arrayPlayerItems"] = {
	},
}