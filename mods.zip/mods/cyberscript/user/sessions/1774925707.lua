-- 1774925350
return {
	["arrayAffinity"] = {
	},
	["arrayQuestStatut"] = {
	},
	["arrayFactionScore"] = {
	},
	["Variable"] = {
		["faction_valentinos"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_delamain"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_animals"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_wraiths"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_maelstrom"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_mox"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["Affinity"] = {
			["faction_aldecaldos"] = 5,
			["faction_voodooboys"] = -10,
			["faction_ncpd"] = 5,
			["Kerry"] = 10,
			["faction_wraith"] = -5,
			["Panam"] = 50,
			["faction_maelstrom"] = -5,
			["faction_mox"] = 5,
			["faction_scavengers"] = -6,
			["Meredith Stout"] = 50,
		},
		["faction_sixthstreet"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["game"] = {
			["loaded_gang_affinity"] = true,
		},
		["player"] = {
			["current_gang"] = "faction_mox",
		},
		["player_position"] = {
			["z"] = "7.187",
			["y"] = "2624.204",
			["x"] = "-1790.980",
		},
		["faction_aldecaldos"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_voodooboys"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_ncpd"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_kangtao"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["player_rotation"] = {
			["roll"] = "0.000",
			["pitch"] = "0.000",
			["yaw"] = "-115.900",
		},
		["current_district"] = {
			["tag"] = "district_watson",
			["subdistrict_enum"] = "Northside",
			["state"] = 1,
			["enum"] = "Watson",
			["districttext"] = "Watson  |  Northside (Neutral)",
			["stateName"] = "Neutral",
		},
		["faction_afterlife"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_maxtac"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_tygerclaws"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_militech"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_arasaka"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_scavengers"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_trauma"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
	},
	["savedStates"] = {
	},
	["garage"] = {
	},
	["arrayHUD"] = {
	},
	["myAvatar"] = "Character.Judy",
	["arrayPlayerItems"] = {
	},
	["arrayHousing"] = {
	},
	["Score"] = {
	},
	["arrayHouseStatut"] = {
	},
	["arrayPlayerData"] = {
	},
}