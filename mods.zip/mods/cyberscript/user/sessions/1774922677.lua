-- 1774922348
return {
	["savedStates"] = {
	},
	["Variable"] = {
		["player"] = {
			["current_gang"] = "faction_mox",
		},
		["faction_kangtao"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_afterlife"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_maxtac"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_tygerclaws"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_wraiths"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_militech"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_scavengers"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_arasaka"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["player_position"] = {
			["y"] = "2621.455",
			["x"] = "-1792.842",
			["z"] = "7.205",
		},
		["Affinity"] = {
			["faction_voodooboys"] = -10,
			["Panam"] = 50,
			["faction_wraith"] = -5,
			["faction_maelstrom"] = -5,
			["faction_mox"] = 5,
			["faction_scavengers"] = -6,
			["Kerry"] = 10,
			["faction_ncpd"] = 5,
			["faction_aldecaldos"] = 5,
			["Meredith Stout"] = 50,
		},
		["faction_sixthstreet"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_trauma"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["game"] = {
			["loaded_gang_affinity"] = true,
		},
		["faction_mox"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_maelstrom"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_voodooboys"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_animals"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_valentinos"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["current_district"] = {
			["enum"] = "Watson",
			["stateName"] = "Neutral",
			["subdistrict_enum"] = "Northside",
			["districttext"] = "Watson  |  Northside (Neutral)",
			["tag"] = "district_watson",
			["state"] = 1,
		},
		["faction_ncpd"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_aldecaldos"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_delamain"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["player_rotation"] = {
			["roll"] = "0.000",
			["pitch"] = "-0.000",
			["yaw"] = "6.850",
		},
	},
	["garage"] = {
	},
	["arrayHUD"] = {
	},
	["myAvatar"] = "Character.Judy",
	["arrayQuestStatut"] = {
	},
	["Score"] = {
	},
	["arrayFactionScore"] = {
	},
	["arrayPlayerData"] = {
	},
	["arrayAffinity"] = {
	},
	["arrayHouseStatut"] = {
	},
	["arrayHousing"] = {
	},
	["arrayPlayerItems"] = {
	},
}