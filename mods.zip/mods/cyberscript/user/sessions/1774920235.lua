-- 1774919935
return {
	["savedStates"] = {
	},
	["Variable"] = {
		["player"] = {
			["current_gang"] = "faction_mox",
		},
		["faction_kangtao"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_afterlife"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_maxtac"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_tygerclaws"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_wraiths"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_militech"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_scavengers"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["game"] = {
			["loaded_gang_affinity"] = true,
		},
		["player_position"] = {
			["y"] = "1273.248",
			["x"] = "-1378.198",
			["z"] = "123.065",
		},
		["Affinity"] = {
			["faction_voodooboys"] = -10,
			["Panam"] = 50,
			["faction_wraith"] = -5,
			["faction_maelstrom"] = -5,
			["faction_mox"] = 5,
			["faction_scavengers"] = -6,
			["Kerry"] = 10,
			["faction_ncpd"] = 5,
			["faction_aldecaldos"] = 5,
			["Meredith Stout"] = 50,
		},
		["faction_mox"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["current_district"] = {
			["enum"] = "Watson",
			["stateName"] = "Neutral",
			["state"] = 1,
			["subdistrict_enum"] = "LittleChina",
			["tag"] = "district_watson",
			["districttext"] = "Watson  |  LittleChina (Neutral)  |  LittleChina_VApartment (Neutral)",
		},
		["faction_sixthstreet"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_arasaka"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_maelstrom"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_voodooboys"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_animals"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_valentinos"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_trauma"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_ncpd"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_aldecaldos"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["faction_delamain"] = {
			["LittleChina"] = 0,
			["Northside"] = 0,
		},
		["player_rotation"] = {
			["roll"] = "0.000",
			["pitch"] = "-0.000",
			["yaw"] = "151.362",
		},
	},
	["garage"] = {
	},
	["arrayHUD"] = {
	},
	["myAvatar"] = "Character.Judy",
	["arrayQuestStatut"] = {
	},
	["Score"] = {
	},
	["arrayFactionScore"] = {
	},
	["arrayPlayerData"] = {
	},
	["arrayAffinity"] = {
	},
	["arrayHouseStatut"] = {
	},
	["arrayHousing"] = {
	},
	["arrayPlayerItems"] = {
	},
}