-- 1774917532
return {
	["myAvatar"] = "Character.Judy",
	["Variable"] = {
		["game"] = {
			["loaded_gang_affinity"] = true,
		},
		["player_position"] = {
			["x"] = "-1378.370",
			["y"] = "1274.342",
			["z"] = "123.065",
		},
		["player_rotation"] = {
			["pitch"] = "-0.000",
			["yaw"] = "145.312",
			["roll"] = "0.000",
		},
		["faction_animals"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_valentinos"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["current_district"] = {
			["stateName"] = "Neutral",
			["tag"] = "district_watson",
			["state"] = 1,
			["enum"] = "Watson",
			["subdistrict_enum"] = "LittleChina",
			["districttext"] = "Watson  |  LittleChina (Neutral)  |  LittleChina_VApartment (Neutral)",
		},
		["faction_trauma"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_ncpd"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_aldecaldos"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_delamain"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_arasaka"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_voodooboys"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_militech"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_kangtao"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_afterlife"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_maelstrom"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_scavengers"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_maxtac"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["Affinity"] = {
			["faction_maelstrom"] = -5,
			["faction_voodooboys"] = -10,
			["Meredith Stout"] = 50,
			["faction_wraith"] = -5,
			["Panam"] = 50,
			["faction_scavengers"] = -6,
			["Kerry"] = 10,
			["faction_aldecaldos"] = 5,
			["faction_ncpd"] = 5,
			["faction_mox"] = 5,
		},
		["faction_tygerclaws"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_sixthstreet"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["player"] = {
			["current_gang"] = "faction_mox",
		},
		["faction_wraiths"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_mox"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
	},
	["arrayHouseStatut"] = {
	},
	["arrayHousing"] = {
	},
	["arrayPlayerItems"] = {
	},
	["savedStates"] = {
	},
	["Score"] = {
	},
	["arrayHUD"] = {
	},
	["arrayPlayerData"] = {
	},
	["arrayAffinity"] = {
	},
	["arrayQuestStatut"] = {
	},
	["arrayFactionScore"] = {
	},
	["garage"] = {
	},
}