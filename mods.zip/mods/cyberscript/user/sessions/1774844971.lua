-- 1774844652
return {
	["Score"] = {
	},
	["myAvatar"] = "Character.Judy",
	["arrayPlayerData"] = {
	},
	["arrayAffinity"] = {
	},
	["arrayHouseStatut"] = {
	},
	["arrayHousing"] = {
	},
	["arrayPlayerItems"] = {
	},
	["savedStates"] = {
	},
	["Variable"] = {
		["Affinity"] = {
		},
	},
	["garage"] = {
	},
	["arrayHUD"] = {
	},
	["arrayFactionScore"] = {
	},
	["arrayQuestStatut"] = {
	},
}