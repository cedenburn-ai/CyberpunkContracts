-- 1774924298
return {
	["arrayHUD"] = {
	},
	["myAvatar"] = "Character.Judy",
	["arrayHousing"] = {
	},
	["Variable"] = {
		["faction_scavengers"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["Affinity"] = {
			["Meredith Stout"] = 50,
			["faction_wraith"] = -5,
			["faction_scavengers"] = -6,
			["faction_maelstrom"] = -5,
			["Panam"] = 50,
			["Kerry"] = 10,
			["faction_aldecaldos"] = 5,
			["faction_mox"] = 5,
			["faction_voodooboys"] = -10,
			["faction_ncpd"] = 5,
		},
		["player_rotation"] = {
			["roll"] = "0.000",
			["pitch"] = "0.000",
			["yaw"] = "79.100",
		},
		["faction_kangtao"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_afterlife"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_maxtac"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_tygerclaws"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_militech"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_arasaka"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_voodooboys"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["current_district"] = {
			["tag"] = "district_watson",
			["enum"] = "Watson",
			["stateName"] = "Neutral",
			["districttext"] = "Watson  |  Northside (Neutral)",
			["state"] = 1,
			["subdistrict_enum"] = "Northside",
		},
		["faction_aldecaldos"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_trauma"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_valentinos"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_delamain"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_animals"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_maelstrom"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_wraiths"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["player_position"] = {
			["z"] = "7.187",
			["x"] = "-1789.952",
			["y"] = "2623.183",
		},
		["player"] = {
			["current_gang"] = "faction_mox",
		},
		["game"] = {
			["loaded_gang_affinity"] = true,
		},
		["faction_mox"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_sixthstreet"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_ncpd"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
	},
	["Score"] = {
	},
	["arrayHouseStatut"] = {
	},
	["arrayPlayerData"] = {
	},
	["arrayAffinity"] = {
	},
	["arrayQuestStatut"] = {
	},
	["arrayFactionScore"] = {
	},
	["arrayPlayerItems"] = {
	},
	["savedStates"] = {
	},
	["garage"] = {
	},
}