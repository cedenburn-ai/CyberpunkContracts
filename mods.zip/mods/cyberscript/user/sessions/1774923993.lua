-- 1774923693
return {
	["garage"] = {
	},
	["Variable"] = {
		["faction_scavengers"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_kangtao"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_afterlife"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_maxtac"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_tygerclaws"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["player"] = {
			["current_gang"] = "faction_mox",
		},
		["faction_militech"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_arasaka"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["Affinity"] = {
			["faction_scavengers"] = -6,
			["faction_wraith"] = -5,
			["faction_mox"] = 5,
			["Meredith Stout"] = 50,
			["faction_maelstrom"] = -5,
			["faction_voodooboys"] = -10,
			["faction_ncpd"] = 5,
			["faction_aldecaldos"] = 5,
			["Panam"] = 50,
			["Kerry"] = 10,
		},
		["faction_voodooboys"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_ncpd"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_aldecaldos"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_trauma"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_maelstrom"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_valentinos"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["current_district"] = {
			["subdistrict_enum"] = "Northside",
			["stateName"] = "Neutral",
			["districttext"] = "Watson  |  Northside (Neutral)",
			["tag"] = "district_watson",
			["state"] = 1,
			["enum"] = "Watson",
		},
		["faction_delamain"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_sixthstreet"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_mox"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["faction_animals"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
		["game"] = {
			["loaded_gang_affinity"] = true,
		},
		["player_position"] = {
			["x"] = "-1789.952",
			["y"] = "2623.183",
			["z"] = "7.187",
		},
		["player_rotation"] = {
			["yaw"] = "79.100",
			["roll"] = "0.000",
			["pitch"] = "0.000",
		},
		["faction_wraiths"] = {
			["Northside"] = 0,
			["LittleChina"] = 0,
		},
	},
	["myAvatar"] = "Character.Judy",
	["arrayHUD"] = {
	},
	["arrayFactionScore"] = {
	},
	["Score"] = {
	},
	["arrayHouseStatut"] = {
	},
	["arrayPlayerData"] = {
	},
	["arrayAffinity"] = {
	},
	["arrayQuestStatut"] = {
	},
	["arrayHousing"] = {
	},
	["arrayPlayerItems"] = {
	},
	["savedStates"] = {
	},
}