-- 1774845211
return {
	["Score"] = {
	},
	["myAvatar"] = "Character.Judy",
	["arrayPlayerData"] = {
	},
	["arrayAffinity"] = {
	},
	["arrayHouseStatut"] = {
	},
	["arrayHousing"] = {
	},
	["Variable"] = {
		["Affinity"] = {
		},
	},
	["savedStates"] = {
	},
	["garage"] = {
	},
	["arrayHUD"] = {
	},
	["arrayPlayerItems"] = {
	},
	["arrayFactionScore"] = {
	},
	["arrayQuestStatut"] = {
	},
}